from dataclasses import field, fields
from importlib import import_module
from operator import imod
from socket import fromshare
from django import forms

from students.models import Student

class StudentForm(forms.ModelForm):
    class Meta:
        model=Student
        fields="__all__"


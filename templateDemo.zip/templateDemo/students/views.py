from socket import MsgFlag
from django.shortcuts import redirect
from django.shortcuts import render,HttpResponse
import students
#loading StudentForm from form.py inside students app
#from app_name.form import ModelForm_name
from students.form import StudentForm
from students.models import Student

# Create your views here.
def index(request):

    if request.method=="POST":
        form=StudentForm(request.POST)

        if form.is_valid():
            form.save() #persist data in database, using queryset(Django ORM API) method==> create
            return redirect("../show")
            return render(show)
        else:
            pass
    else:
        obj=StudentForm()
        return render(request,'index.html',{'stu':obj})

def show(request):  
        students = Student.objects.all()  
        return render(request,"show.html",{'stu_list':students}) 

def edit(request, id):  
        stu = Student.objects.get(id=id)  
        return render(request,'edit.html', {'stu':stu})

def update(request, id):  
        stu = Student.objects.get(id=id)  
        form = StudentForm(request.POST, instance = stu)  
        if form.is_valid():  
            form.save()  
            return redirect("../show")

        return render(request, 'edit.html', {'stu': stu}) 


def destroy(request, id):  
        stu = Student.objects.get(id=id)  
        stu.delete()  
        return redirect("../show") 

def new_func():
    return redirect('show')


def upload(request):
    obj=StudentForm()
    return render(request,'upload.html',{'stu':obj})